<!DOCTYPE html>

<html lang="en">
    <head>
        <!-- Google Tag Manager MFI -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KBTHCK8');</script>


<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TGNCQBD');</script>
<!-- End Google Tag Manager -->
<!-- Google tag (gtag.js) --> 
<script async src="https://www.googletagmanager.com/gtag/js?id=G-56FERT50QN"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-56FERT50QN'); </script>
        <title>Page not found</title>

        <meta charset="utf-8">
        <meta name="keywords" content="umrah, umrah packages, umrah packages from Mumbai, umrah packages from Mumbai 2022, Umrah Tour Packages, Hajj and Umrah Travel, Hajj Umrah 2022, umrah packages in india, umrah group tours, umrah from india, Umrah 2022, budget Umrah Packages, Atlas tours and travels,Umrah Packages 2022,Umrah Package, Umrah Tour Packages, umrah packages in india, Umrah Packages from mumbai 2021 , Umrah with Turkey,  umrah group tours, umrah package from mumbai, umrah from india, Umrah 2021, Umrah Packages 2022, Umrah Packages 2022,Umrah Packages from mumbai 2022 , Umrah Packages, low umrah packages, cheap umrah packages, saudi arabia umrah packages from india, baghdad sharif tour package from mumbai, Baghdad Sharif Ziyarat Package, Umrah Tour Operator in Mumbai, Hajj Umrah 2022">
        <meta name="description" content="Atlas Umrah - A Product of Atlas Tours & Travels - is India's National Umrah Brand, providing exceptional services for Umrah, Hajj, Ziyarat, and Ramadan pilgrimages for over 35 years. Our team of experts ensures every aspect of your journey is handled with care and precision. Trust us to make your pilgrimage or Ramadan experience a spiritual and memorable one. We offer the best Umrah, Hajj, and Ziyarat packages, with daily departures and hotels near the holy sites in Mecca and Medina. Choose from different packages that suit your budget, from cheap to luxury options. Make your journey hassle-free with Atlas Tours & Travels. We have departures from Mumbai, Ahmedabad, Banglore, Delhi, Hyderabad, Kolkatta">

        <meta property="og:title" content="Atlas Umrah | India's National Umrah Brand | Daily Umrah Group Tours from all over India" />
        <meta property="og:site_name" content="Atlas Umrah" />
        <meta property="og:type" content="website" />
        <meta property="og:description" content="Atlas Umrah - A Product of Atlas Tours & Travels - is India's National Umrah Brand, providing exceptional services for Umrah, Hajj, Ziyarat, and Ramadan pilgrimages for over 35 years. Our team of experts ensures every aspect of your journey is handled with care and precision. Trust us to make your pilgrimage or Ramadan experience a spiritual and memorable one. We offer the best Umrah, Hajj, and Ziyarat packages, with daily departures and hotels near the holy sites in Mecca and Medina. Choose from different packages that suit your budget, from cheap to luxury options. Make your journey hassle-free with Atlas Tours & Travels. We have departures from Mumbai, Ahmedabad, Banglore, Delhi, Hyderabad, Kolkatta" />
        <meta property="og:url" content="//atlasumrah.com/umrah-detail.html" />
        <meta property="og:image" content="//atlasumrah.com/assets/frontend_end/images/logo.png" />

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Google tag (gtag.js) --> 
<script async src="https://www.googletagmanager.com/gtag/js?id=G-56FERT50QN"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-56FERT50QN'); </script><!-- FONT CSS-->
<link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900">
<link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Montserrat:400,700">
<!--<link type="text/css" rel="stylesheet" href="assets/frontend_end/font/font-icon/font-awesome/css/font-awesome.css"> -->
<link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/font/font-icon/font-flaticon/flaticon.css">
<!-- LIBRARY CSS-->
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/libs/bootstrap/css/bootstrap.min.css">
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/libs/animate/animate.css">
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/libs/slick-slider/slick.css">
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/libs/slick-slider/slick-theme.css">
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/libs/selectbox/css/jquery.selectbox.css">
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/libs/please-wait/please-wait.css">
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/css/custom.css">
<!-- STYLE CSS-->
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/css/layout.css">
<!--
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
-->

<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/css/captcha.css">
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/css/components.css">
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/css/responsive.css">
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/libs/nst-slider/css/jquery.nstSlider.min.css">
<link type="text/css" rel="stylesheet" href="https://www.atlasumrah.com/assets/frontend_end/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css">

<!-- Owl Carousel Assets -->
<link href="https://www.atlasumrah.com/assets/frontend_end/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="https://www.atlasumrah.com/assets/frontend_end/owl-carousel/owl.theme.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>

<!-- Silent Coders -->
<link href="https://www.atlasumrah.com/css/custom.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://www.atlasumrah.com/plugins/image-tam-carousel/TAMcarousel/TAMcarousel.css" />
<!--/ Silent Coders -->

<link type="text/css" rel="stylesheet" href="http://code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css"><!-- Facebook Pixel Code -->
  <script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '167021983891129');
    fbq('track', 'PageView');
  </script>
  <!-- End Facebook Pixel Code -->
  <!-- Global site tag (gtag.js) - Google Analytics -->
  <!--<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100385915-1"></script>-->
  <!--<script>-->
  <!--  window.dataLayer = window.dataLayer || [];-->
  <!--  function gtag(){dataLayer.push(arguments);}-->
  <!--  gtag('js', new Date());-->

  <!--  gtag('config', 'UA-100385915-1');-->
  <!--</script>--><!-- Meta Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '917463325807559');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=917463325807559&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<script src='https://www.google.com/recaptcha/api.js' async defer></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script src="https://kit.fontawesome.com/c00a39a895.js" crossorigin="anonymous"></script>

<script>
    (function(w,d,s,c,r,a,m){
      w['KiwiObject']=r;
      w[r]=w[r] || function () {
        (w[r].q=w[r].q||[]).push(arguments)};
      w[r].l=1*new Date();
        a=d.createElement(s);
        m=d.getElementsByTagName(s)[0];
      a.async=1;
      a.src=c;
      m.parentNode.insertBefore(a,m)
    })(window,document,'script',"https://app.interakt.ai/kiwi-sdk/kiwi-sdk-17-prod-min.js?v="+ new Date().getTime(),'kiwi');
    window.addEventListener("load",function () {
      kiwi.init('', 'MlsRs8GgTuKmFvx0gbyEMd3eG9H5qZQC', {});
    });
  </script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TGNCQBD');</script>
<!-- End Google Tag Manager -->
        
        <link rel="stylesheet" type="text/css" href="https://www.atlasumrah.com/css/umrah-packages.css" />
  
    </head>
   
<body class="innerPage">
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TGNCQBD"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    
    <div class="body-wrapper">
    <!-- MENU MOBILE-->
    <!-- WRAPPER CONTENT-->
    <div class="wrapper-content">
      
        <!-- HEADER-->
 
    
         
            <div class="header-main" style="position:fixed;background:white">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                            <div class="logo"><a href="/" class="header-logo"><img src="https://www.atlasumrah.com/assets/frontend_end/images/logo.png" alt="Atlas Umrah"/></a></div>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-12" style="padding-top: 15px;">
                            <div class="row">
                               
                                <div class="col-lg-offset-0 col-lg-9 col-md-offset-2 col-md-8 pull-right">

                                    <nav id='flexmenu' class="pull-right">
                                      <div id="mobile-toggle" class="mobile-menu"></div>
                                        <ul id="main-menu" class="pull-right">
                                        
                                        <li class="main-menu-item menuHover arrowMenuDown"><a href='#' class="menuBar">Umrah</a>
                                           <ul class="sub-menu" style="background:#FFFFFF">
                                              <li><a href='#'>Awwal&#8482; Umrah<span style="font-size:20px;float:right;color:blue;font-weight:bold;margin-top:-8px;">&#8594;</span></a>
                                             
                                                    <ul class="sub-submenu" class="sub-submenu" style="background:white">
                                            <li><a href='https://www.atlasumrah.com/umrah-packages-from-mumbai-2022.php'>Mumbai</a></li>
                                                  <li><a href='https://www.atlasumrah.com/umrah-packages-from-bangalore-2022.php'>Bangalore</a></li>
                                                 
                                                  <li><a href='https://www.atlasumrah.com/umrah-packages-from-ahmedabad-2022.php'>Ahmedabad</a></li>
                                               </ul>
                                              </li>
                                              <li><a href='#'>Aala&#8482; Umrah<span style="font-size:20px;float:right;color:blue;font-weight:bold;margin-top:-8px;">&#8594;</span></a>
                                              
                                                    <ul class="sub-submenu" style="background:#FFFFFF">
                                             <li><a href='https://www.atlasumrah.com/umrah-packages-from-mumbai-2022.php'>Mumbai</a></li>
                                                  <li><a href='https://www.atlasumrah.com/umrah-packages-from-bangalore-2022.php'>Bangalore</a></li>
                                                
                                                  <li><a href='https://www.atlasumrah.com/umrah-packages-from-ahmedabad-2022.php'>Ahmedabad</a></li>
                                               </ul>
                                              </li>
                                              
                                                <li><a href='#'>Aala +&#8482; Umrah<span style="font-size:20px;float:right;color:blue;font-weight:bold;margin-top:-8px;">&#8594;</span></a>
                                              
                                                    <ul class="sub-submenu" style="background:#FFFFFF">
                                             <li><a href='https://www.atlasumrah.com/umrah-packages-from-mumbai-2022.php'>Mumbai</a></li>
                                                  <li><a href='https://www.atlasumrah.com/umrah-packages-from-bangalore-2022.php'>Bangalore</a></li>
                                                
                                                  <li><a href='https://www.atlasumrah.com/umrah-packages-from-ahmedabad-2022.php'>Ahmedabad</a></li>
                                               </ul>
                                              </li>
                                              
                                              
                                              <li><a href='#'>Azeem&#8482; Umrah<span style="font-size:20px;float:right;color:blue;font-weight:bold;margin-top:-8px;">&#8594;</span></a>
                                              
                                                    <ul class="sub-submenu" style="background:#FFFFFF"> 
                                            <li><a href='https://www.atlasumrah.com/umrah-packages-from-mumbai-2022.php'>Mumbai</a></li>
                                                  <li><a href='https://www.atlasumrah.com/umrah-packages-from-bangalore-2022.php'>Bangalore</a></li>
                                                  
                                                  <li><a href='https://www.atlasumrah.com/umrah-packages-from-ahmedabad-2022.php'>Ahmedabad</a></li>
                                               </ul>
                                              </li>
                                              
                                           
                                           </ul>
                                        </li>
                                        <li class="main-menu-item menuHover arrowMenuDown"><a href='#' class="menuBar">Hajj</a>
                                          

                                           <ul class="sub-menu" style="background:#FFFFFF">
                                               <li><a href='https://www.atlasumrah.com/hajj-from-mumbai-2023.php'>Mumbai</a></li>
                                                  <li><a href='https://www.atlasumrah.com/hajj-from-bangalore-2023.php'>Bangalore</a></li>
                                                 
                                                  <li><a href='https://www.atlasumrah.com/hajj-from-ahmedabad-2023.php'>Ahmedabad</a></li>
                                           </ul>
                                        </li>
                                        <li class="main-menu-item menuHover"><a href='https://www.atlasumrah.com/ziyarat.php'>Ziyarat</a></li>
                                        <li class="main-menu-item menuHover arrowMenuDown"><a href='#'>Ramzan</a>
                                        
                                           <ul class="sub-menu" style="background:#FFFFFF">
                                               <li><a href='https://www.atlasumrah.com/ramzaan-umrah-packages-from-mumbai-2023.php'>Mumbai</a></li>
                                                  <li><a href='https://www.atlasumrah.com/ramzaan-umrah-packages-from-bangalore-2023.php'>Bangalore</a></li>
                                                 
                                                  <li><a href='https://www.atlasumrah.com/ramzaan-umrah-packages-from-ahmedabad-2023.php'>Ahmedabad</a></li>
                                           </ul>
                                        
                                        
                                        </li>
                                         <li class="main-menu-item menuHover"><a id="customUmrah" style="text-align:center;" href='#'>Custom Umrah</a></li>
                                        <li class="main-menu-item menuHover"><a href='#'>Blogs</a></li>
                                                      
                                        <li class="main-menu-item menuHover"><a class="contactUsMenu" href='https://www.atlasumrah.com/contact-us.php'>Contact Us</a></li>
                                        <li class="main-menu-item trackYourBooking"><a href='https://booking.atlasumrah.com/b2c/trackbooking.aspx' target="_blank"><span class="">Track Booking</span></a></li>
                                        <li class="main-menu-item agent-login" style="">
                                          <a href="https://booking.atlasumrah.com/bacKoffice/sigNin.aspx" target="_blank" class="" >
                                         <span class="" style="">Agent Login</a>
                                        </li>
                                      </ul>

                                    </nav>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3"></div>
                    </div>
                </div>
            </div>
   
          
                
        
                
        
        
        
        
        <!-- Breadcrumbs -->
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="package-breadcrumb">
                        Home > Types of Packages > <strong>Mumbai</strong>
                    </div>
                </div>
            </div>
        </div> 
        <!--/ Breadcrumbs -->
        
        <div class="container firstBlock" id="PackageName" style="margin-top:76px;">
            <div class="row">
                <div class="col-lg-10">
                   
                </div>
                <div class="col-lg-2">
                  <!--    <div class="package-starts-from">
                        <div class="price-starts-from">
                            Prices starting from
                        </div>
                        <div class="price-starts-from-price">
                            105,000                        </div>
                    </div>     -->                     
                </div>
            </div>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <div>
                        <div class="row">
                            <div class="col-lg-12" style="margin-left:10%;margin-right:10%">
                                <!-- Picture -->
                                <div class="package-picture">
                            <img alt="Page not found" src="https://www.atlasumrah.com/images/pagenotfound.png" />
                                </div>
                                <!--/ Picture -->
                                
                                <!--
                                <p class="text" style="text-align:justify">Atlas Tours and Travels has been catering to Umrah Pilgrims with the best and Luxury Umrah Package From Mumbai 2022. Our team of Atlas Umrah provides the desirous of performing Umrah Tour Package from Mumbai for a lifelong experience of Makkah and the holy places. Avail quality Umrah services and facilities throughout your journey of Makkah, Madinah and nearby holy places. Opt for 14 days Luxury Umrah package from Mumbai 2022 for yourself and your family. Choose from the best of our Awwal, Aala and Azeem Umrah Packages 2022.</p>
                                -->
                            </div>
                           
                        </div>
                       
                        
                    </div>
                   
                </div>
                  
               
            </div>
        </div>
        

    <div id="wrapper-content">
        
        <!-- MAIN CONTENT-->
        <div class="main-content">          
            
          <div class="news padding-top padding-bottom">
            <div class="container">
                <div class="paymentDiv">
                    <div class="col-md-12" style="text-align: center;">
                        <div class="title">All Major Credit cards are accepted at our branches </div>
                        <img src="https://www.atlasumrah.com/img/icons/credit-card-bar.png" style="height: 50px;" />
                    </div>
                </div>
                
               
                
              <div class="news-wrapper" style="display:none">
                <div class="box3">
                  <div class="col-md-4"><img alt="Atlas Umrah footer logo" src="https://www.atlasumrah.com/assets/frontend_end/images/logo/atlas.png"></div>
                  <div class="col-md-8 subscribeBt">
                    <div class="subscribe-email-left">
                      <p class="subscribe-email-title">Subscribe to our newsletter for latest offers and deals.</p>
                    </div>
                    
                  
                                        <div class="subscribe-email-right">
                        <form action="newsletter-form.php" method="post" id="newsletter-form"  name="newsletter-form">
                            <div class="input-group form-subscribe-email">        
                                <input type="reset" class="hidden" name="reset_newsletter-form" id="reset_newsletter-form" />
                                <input class="form-control" name="email" placeholder="Enter your email" required="" type="email"> <span class="input-group-btn"><button class="btn-email" type="submit" id="submit_newsletter"><span class="input-group-btn">→</span></button></span>
                                
                            </div>
                            <div class="g-recaptcha" data-sitekey="6Lde2zojAAAAACvj4hFz8ds6q6ucw4BcCdHOq_CG"></div>
                        </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
             <div style="padding-bottom: 40px; background: #F8F8F8;padding: 40px 0 0;">
                <div class="PackageMoreDetails">
                    <div id="cutText" class="PackageMoreDetailsHide">
                        
                        <div style="word-wrap: break-word;">
                            <h3 style="   margin-bottom: 5px;    font-weight: 500;    margin-top: 0;"><strong style="    font-weight: bolder;    font-size: 16px;line-height: 22px;  margin-bottom: 5px;    letter-spacing: normal;">Find the best umrah packages at Atlas Umrah - A Product of Atlas Tours & Travels Pvt Ltd</strong></h3>
                            <p style=" display: block; margin-bottom: 15px; font-size: 12px;    margin-top: 0; line-height: 20px;">
                                We are providing exceptional services for over 35 years. Our team of experts ensures every aspect of your journey is handled with care and precision, with a focus on creating a spiritual and memorable experience.If you're planning to embark on an Umrah pilgrimage, you want to ensure that every detail is taken care of, so that you can focus on your spiritual journey. That's why Atlas Tours & Travels is the best choice for your Umrah packages. We are a top-rated travel agency that specializes in providing holistic travel experiences for our customers.</p>
                            
                             <p style=" display: block; margin-bottom: 15px; font-size: 12px;    margin-top: 0; line-height: 20px;">As a leading Umrah travel agency, we understand that travelling is much more than just reaching your destination. It's about creating unforgettable memories, experiencing new cultures and immersing yourself in spirituality. At Atlas Tours & Travels, we strive to offer our customers the best possible Umrah packages, that are tailored to their unique needs.We offer a wide range of packages to suit your budget, with daily departures and hotels located near the holy sites in Mecca and Medina</p>
                             
                              <p style=" display: block; margin-bottom: 15px; font-size: 12px;    margin-top: 0; line-height: 20px;">One of the biggest advantages of choosing Atlas Tours & Travels is that we provide comprehensive services to ensure that your travel experience is as smooth and hassle-free as possible. We offer customized packages to fit your budget, preferences, and schedules, which are designed to cater to both individual and group travel requirements.

In addition to that, we offer comfortable and luxurious accommodation options that are located in close proximity to the Haram Shareef, allowing our guests to easily perform their religious obligations without any inconvenience. Our 14-day Umrah packages are designed to give you ample time to offer prayers, perform Tawaf, and other religious duties while also allowing you to experience the local culture and cuisine of the cities.

At Atlas Tours & Travels, we also take care of your Umrah visa processing needs, so that you can focus on your religious duties instead of worrying about the paperwork. Our visa processing services are efficient and hassle-free, ensuring that you receive your Umrah visa well before your travel dates.

Moreover, we have a team of experienced and knowledgeable staff who are available 24/7 to assist you with any queries or concerns that you may have during your journey. We also provide transportation services to ensure that you are comfortable and safe while traveling between different locations.

In summary, whether you are planning a trip for Hajj, Umrah, or Ziyarat, Atlas Tours & Travels is the go-to choice for hassle-free and convenient travel services. With a focus on providing the best possible experience, we ensure that your journey is memorable and rewarding.</p>
                               
                              
                        </div>
                        <div style="position: absolute;bottom: 0; width: 100%;height: 4em; "></div>
                        
                    </div>
                    
                    <button class="MoreButton">Read More</button>
                    
                </div>
                </div>
          </div>
        </div><!-- BUTTON BACK TO TOP-->
<div id="back-top">
    <a href="#top" class="link">
        <i class="fa fa-angle-double-up"></i>
    </a>
</div>    
    </div>

    <link rel="stylesheet" type="text/css" href="css/footer.css" />
<!-- FOOTER-->
    <footer>
    <!--
      <div class="footer-main">
          
          <div class="container">
            <div class="footer-main-wrapper">
              <div class="row">
                <ul class="footerbox">
                  <li>
                    <a href="#" target="_blank"><img alt="B2B travel portal" src="assets/frontend_end/images/icons/b2bportal.png"></a>
                  </li>
                  <li>
                    <a href="http://atlasumrah.com/"><img alt="Hajj & Umrah" src="assets/frontend_end/images/icons/hajj-umrahService.png"></a>
                  </li>
                  <li class="middlediv">
                    <a href="http://atlastravels.com/" target="_blank"><img alt="Atlas Tours & Travels" src="assets/frontend_end/images/icons/atlastours.png"></a>
                  </li>
                  <li>
                    <a href="http://www.grandresidency.com/" target="_blank"><img alt="Grand Residency" src="assets/frontend_end/images/icons/hotelService.png"></a>
                  </li>
                  <li>
                    <a href="#" target="_blank"><img alt="Visa Services" src="assets/frontend_end/images/icons/visaService.png"></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
         
        </div>
     -->
    <div class="footer-main" style="background:black">
        <div class="container" style="width:1280px;">
            <div class="row">
                <div class="col-lg-3" style="width:20%;text-align: -webkit-center;"><div style=" padding: 10px 0;width: 200px; margin-left: 0px;"><a href="/" class="header-logo"><img style="width: 100%;margin-left: 17px;    vertical-align: middle;" src="https://www.atlasumrah.com/assets/frontend_end/images/logo.png" alt="Atlas Umrah Logo"></a></div>
                <span style="font-size:13px">53 Haji Mahal, <br>
                Mohammed Ali Road,<br>
                Mumbai 400003</span><br/>
                <span style="font-size:13px">+91-2261411000 </span>
                </div>
                
                <div class="col-lg-3" style="width:20%; display:inline-block">
                    <h4 style="font-size:11px;font-family: 'poppins_regular' !important;font-weight: 600;">Awwal Umrah</h4>
                    <ul>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-mumbai-2022.php">Umrah Groups from Mumbai</a></li>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-bangalore-2022.php">Umrah Groups from Bangalore</a></li>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-hyderabad-2022.php">Umrah Groups from Hyderabad</a></li>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-ahmedabad-2022.php">Umrah Groups from Ahmedabad</a></li>
                    </ul>
                </div>
                <div class="col-lg-3" style="width:20%; display:inline-block">
                    <h4 style="font-size:11px;font-family: 'poppins_regular' !important;font-weight: 600;">Aala Umrah</h4>
                  <ul>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-mumbai-2022.php">Umrah Groups from Mumbai</a></li>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-bangalore-2022.php">Umrah Groups from Bangalore</a></li>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-hyderabad-2022.php">Umrah Groups from Hyderabad</a></li>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-ahmedabad-2022.php">Umrah Groups from Ahmedabad</a></li>
                    </ul>
                </div>
                <div class="col-lg-3" style="width:20%; display:inline-block">
                    <h4 style="font-size:11px;font-family: 'poppins_regular' !important;font-weight: 600;">Azeem Umrah</h4>
                    <ul>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-mumbai-2022.php">Umrah Groups from Mumbai</a></li>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-bangalore-2022.php">Umrah Groups from Bangalore</a></li>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-hyderabad-2022.php">Umrah Groups from Hyderabad</a></li>
                        <li><a style="font-size: 10px; color: white;" href="../umrah-packages-from-ahmedabad-2022.php">Umrah Groups from Ahmedabad</a></li>
                    </ul>
                </div>
                <div class="col-lg-3" style="width:20%; display:inline-block">
                    <h4 style="font-size:11px;font-family: 'poppins_regular' !important;font-weight: 600;">Company</h4>
                    <ul>
                        <li><a style="font-size: 10px; color: white;" href="
                        /contact-us.php">Contact Us</a></li>
                        <li><a style="font-size: 10px; color: white;" href="https://booking.atlasumrah.com/TermsOfService.aspx">Terms Of Service </a></li>
                        <li><a style="font-size: 10px; color: white;" href="https://booking.atlasumrah.com/PrivacyPolicy.aspx">Privacy Policies</a></li>
                        <li><a style="font-size: 10px; color: white;" href="https://booking.atlasumrah.com/UserAgreement.aspx">Terms & Conditions</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="hyperlink">
        <div class="container">
          <div class="name-company">&copy; All rights reserved | Copyright <script>
                var currentTime = new Date()
                var year = currentTime.getFullYear()
                document.write(year)
                //-->
                </script> Atlas Tours and Travels Pvt Ltd</div>
          <div class="social-footer">
            <ul class="list-inline list-unstyled">
              <li><a href="https://www.facebook.com/AtlasToursTravels/" target="_blank"  class="link facebook"><i style="color: #0165E1;" class="fa fa-facebook"></i></a></li>
                <li><a href="https://www.youtube.com/AtlasUmrah" target="_blank"  class="link pinterest"><i style="color: #FF0000;" class="fa fa-youtube"></i></a></li>
                <li><a href="https://twitter.com/Atlas_Travels" target="_blank"  class="link twitter"><i style="color: #1DA1F2;" class="fa fa-twitter"></i></a></li>
                <li><a href="https://www.instagram.com/atlastourstravels/" target="_blank" class="link insta"><i style="color: #3f729b;" class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
<script type="text/javascript" src="js/footer.js"></script>      
    </div>
  </div><!-- LIBRARY JS-->
  <!-- LIBRARY JS-->  
  
  
    
<!-- line modal -->
<div class="modal fade" id="squarespaceModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
			<h3 class="modal-title">My Modal</h3>
		</div>
		<div class="modal-body form_Set">
			
            <!-- content goes here -->
			<form>
       <input type="hidden" name="token" value="b4704c5069ac9751c382d2ab3b89ff60_||_ns" />
              <div class="form-group">
                <label for="exampleInputEmail1">Email address</label>
                <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
              </div>
              <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
              </div>
              <div class="form-group">
                <label for="exampleInputFile">File input</label>
                <input type="file" id="exampleInputFile">
                <p class="help-block">Example block-level help text here.</p>
              </div>
              <div class="checkbox">
                <label>
                  <input type="checkbox"> Check me out
                </label>
              </div>
              <button type="submit" class="btn btn-default">Submit</button>
            </form>

		</div>
		<div class="modal-footer">
			<div class="btn-group btn-group-justified" role="group">
				<div class="btn-group" role="group">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
				<div class="btn-group btn-delete hidden" role="group">
					<button type="button" id="delImage" class="btn btn-default btn-hover-red" data-dismiss="modal">Delete</button>
				</div>
				<div class="btn-group" role="group">
					<button type="button" id="saveImage" class="btn btn-default btn-hover-green" data-action="save">Save</button>
				</div>
			</div>
		</div>
	</div>
  </div>
</div>

<!-- Inquire modal -->
<div class="modal fade popupStyle" id="inquiryForm" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
        <h3 class="modal-title">Inquiry Request For Tours 2021 - 2022 </h3>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
          <h4 class="formSubtext">Please fill up the form below to get a call from us</h4>
        </div>
        <!--  <div class="col-md-6"> </div> -->
        <div class="popupForm form_Set">
            <form class="popupStyle" method="post" action="booking-request.php" id="booking-request">
              <input type="hidden" name="subject" value="Booking Request Form" />
              <div class="form-group">
                <label>Your Name</label>
                <span class="formIcon"> <img src="assets/frontend_end/images/icons/name.png" alt="user icon"></span>
                <input type="text" name="requestName" required class="form-control validateName"  placeholder="">
              </div>
              <div class="form-group">
                <label>Email Id</label>
                <span class="formIcon"> <img src="assets/frontend_end/images/icons/emailB.png" alt="Email icon"></span>
                <input type="email" name="requestEmail" required class="form-control"  placeholder="">
              </div>
              <div class="form-group">
                <label>Mobile No</label>
                <span class="formIcon"> <img src='assets/frontend_end/images/icons/phoneB.png' alt="Mobile icon"> </span>
                <input type="tel" name="requestNumber" required class="form-control validateContact"  placeholder="">
              </div>
              <div class="form-group">
            <label>Tour Name</label>
            	<div class=" select-drop">
                          <label>
                            <select class="chosen-select" name="umrahType">                              
                              <option value="Awwal Umrah">Awwal Umrah</option>
                               <option value="Aala Umrah">Aala Umrah</option>
                              <option value="Azeem Umrah">Azeem Umrah</option>
                              <option value="Corporate Umrah">Corporate Umrah</option>
                              <option value="Ramadan Umrah">Ramadan Umrah</option>
                              <option value="Shaban Ramzan Umrah">Shaban Ramzan Umrah</option>
                            </select>
                          </label>
                        </div>
            </div>
             <div class="form-group">
              <label>Preferred Date</label>
               <span class="formIcon"><img src="assets/frontend_end/images/icons/calendarB.png" alt="Calendar icon"></span>
              <input type="text" class="form-control date-input2 " placeholder="" name="preferredDate">
            </div>
             
              <button type="submit" class="btn btn-default submitFrom">Submit</button>
            </form>
            <div class="thankyouFromMessage hidden">
              <h3>Thank you for contacting us!</h3>
              One of our representatives will call or email you to address your requirement </div>
          </div>
      </div>
    </div>
  </div>
</div>
<!--end Inquire modal --> 

<div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Subscribe our Newsletter</h4>
            </div>
            <div class="modal-body">
				<p>Subscribe to our mailing list to get the latest updates straight in your inbox.</p>
                <form>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Name">
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" placeholder="Email Address">
                    </div>
                    <button type="submit" class="btn btn-primary">Subscribe</button>
                </form>
            </div>
        </div>
    </div>
</div>



<!-- callBack modal -->
<div class="modal fade popupStyle" id="callBackForm" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
        <h3 class="modal-title">Request a Call Back </h3>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
          <h4 class="formSubtext">Please fill up the form below to get a call from us</h4>
        </div>
        <!--  <div class="col-md-6"> </div> -->
        <div class="popupForm form_Set">
            <form class="popupStyle" method="post" action="callBackrequest.php" id="callBack-request">
              <input type="hidden" name="subject" value="Call Back Request Form" />
              <div class="form-group">
                <label>Your Name</label>
                <span class="formIcon"> <img src="assets/frontend_end/images/icons/name.png" alt="user icon"></span>
                <input type="text" name="requestName" required class="form-control validateName"  placeholder="">
              </div>
              
              <div class="form-group">
                <label>Mobile No</label>
                <span class="formIcon"> <img src="assets/frontend_end/images/icons/phoneB.png" alt="mobile icon"> </span>
                <input type="tel" name="requestNumber" required class="form-control validateContact"  placeholder="">
              </div>
              
             
             
              <button type="submit" class="btn btn-default submitFrom">Submit</button>
            </form>
            <div class="thankyouFromMessage hidden">
              <h3>Thank you for contacting us!</h3>
              One of our representatives will call or email you to address your requirement </div>
          </div>
      </div>
    </div>
  </div>
</div>
<!--end callBack modal -->
<!-- 
<div class="modal fade popupStyle" id="imagesGallery" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="background-image: none !important; background-color: #FFFFFF;">
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
        <h3 class="modal-title galleryTitle"> Gallery </h3>
      
      </div>
      <div class="modal-body">

         
          <div class="gethotel_gallery">
              <iframe width="100%" height="400" style="border: 0;" src=""></iframe>
          </div>

  </div>
</div>
</div>
</div> -->

<!-- umrah Inquire modal -->
<div class="modal fade popupStyle" id="umrahInquireNow" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
        <h3 class="modal-title">Inquiry for  Umrah <span class="tourYear"></span> </h3>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
          <h4 class="formSubtext">Please fill up the form below to get a call from us</h4>
        </div>
        <div class="col-md-12">
          <div class="popupForm">
          <form>
          <div class="row">
                  <div class="col-md-6">
                      <div class="form-group"> 
                        <label>Traveling Date</label>
                        <div class="borField2 deptDateDisp"></div>
                      </div>
                    </div>
                 <div class="col-md-6">
                  <div class="form-group"> 
                    <label>Departure City</label>
                    <div class="borField2 deptCityDisp"></div>
                  </div>
                </div>
           </div>
           
           
            <div class="form-group"> <span class="formIcon"><img src="assets/frontend_end/images/icons/name.png" alt="user icon"></span>
              <input type="text" class="form-control validateName"  placeholder="Your Name">
            </div>
            <div class="form-group"> <span class="formIcon"><img src="assets/frontend_end/images/icons/emailB.png" alt="email icon"></span>
              <input type="email" class="form-control"  placeholder="Email Id">
            </div>
            <div class="form-group"> <span class="formIcon"><img src="assets/frontend_end/images/icons/phoneB.png" alt="mobile icon"></span>
              <input type="number" class="form-control validateContact"  placeholder="Mobile No">
            </div>
            <div class="col-md-4">
              <div class="form-group"> 
                <!--<span class="formIcon"></span>-->
                <label>No. of Adult</label>
                <input type="number" class="form-control validateContact" placeholder="">
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label>No. of Child</label>
                <input type="number" class="form-control validateContact" placeholder="">
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label>No. of Infant</label>
                <input type="number" class="form-control validateContact" placeholder="">
              </div>
            </div>
            <button type="submit" class="btn btn-default">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<!--end umrah Inquire modal -->



<div class="modal fade popupStyle2" id="checkNow" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
        <h3 class="modal-title" id="lineModalLabel">Available Umrah package for date <strong><span class="depDateDisp"></span></strong> with Departure city <strong><span class="depCityDisp"></span></strong></h3>
      </div>
      <div class="modal-body">
      <div class="request_loader"><i class="fa fa-spinner fa-pulse fa-3x fa-fw margin-bottom"></i></div>        
        <ul class="searchResults"></ul>                
    </div>
  </div>
</div>
</div>
<!--end callBack modal --> 
<a href="tel:+912261411000" style="bottom: 26px; right: 252px; z-index: 999999999; position: fixed; background: #01427a; border-radius: 25px; padding: 7px 12px 7px 12px;">
    <i class="fa fa-phone" style="color: white;"> </i>
</a>

<!-- LIBRARY JS--> 
<script src="https://www.atlasumrah.com/assets/frontend_end/libs/jquery/jquery-2.2.3.min.js"></script> 
<script src="https://www.atlasumrah.com/assets/frontend_end/libs/bootstrap/js/bootstrap.min.js"></script> 
<script src="https://www.atlasumrah.com/assets/frontend_end/libs/detect-browser/browser.js"></script> 
<script src="https://www.atlasumrah.com/assets/frontend_end/libs/smooth-scroll/jquery-smoothscroll.js"></script> 
<script src="https://www.atlasumrah.com/assets/frontend_end/libs/wow-js/wow.min.js"></script> 
<script src="https://www.atlasumrah.com/assets/frontend_end/libs/selectbox/js/jquery.selectbox-0.2.js"></script> 
<!--<script src="assets/libs/please-wait/please-wait.min.js"></script>--> 
<!--script(src="assets/libs/parallax/jquery.data-parallax.min.js")--><!-- MAIN JS--> 
<script src="https://www.atlasumrah.com/js/captcha.js"></script> 
<!-- LOADING JS FOR PAGE--> 
<script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

<!--<script src="assets/frontend_end/js/custom.js"></script>-->
          
<script src="https://www.atlasumrah.com/assets/frontend_end/js/form/jquery.form.min.js"></script>
<script src="https://www.atlasumrah.com/assets/frontend_end/js/form/jquery.validate.min.js"></script>
 
<script type="text/javascript">
_linkedin_partner_id = "4363620";
window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
window._linkedin_data_partner_ids.push(_linkedin_partner_id);
</script><script type="text/javascript">
(function(l) {
if (!l){window.lintrk = function(a,b){window.lintrk.q.push([a,b])};
window.lintrk.q=[]}
var s = document.getElementsByTagName("script")[0];
var b = document.createElement("script");
b.type = "text/javascript";b.async = true;
b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
s.parentNode.insertBefore(b, s);})(window.lintrk);
</script>
<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=4363620&fmt=gif" />
</noscript>


<script>
(function($) {
 "use strict";

	$(function()
	{
		// Validation
		$("#booking-request").validate(
		{					
			// Rules for form validation
			rules:
			{
				requestName:
				{
					required: true,
					alpha:true,
				},
				requestEmail:
				{
					required: true,
					email: true,
				},
				
				
				requestNumber:
				{
				required: true,
				digits:true,
				minlength:8,
				maxlength:10,
				}
				
				
			},
								
			// Messages for form validation
			messages:
			{
				requestName:
				{
					required: 'Please enter your name',
					digit:'Please enter a VALID name',
					alpha: "Please enter a VALID name",
				},
				requestEmail:
				{
					required: 'Please enter your email address',
					email: 'Please enter a VALID email address'
				},
				
				requestNumber:
				{
				required: 'Please enter phone number',
				digits:'Please enter a VALID phone number',
				minlength:'Please enter a VALID phone number (8-10 digits)',
				maxlength:'Please enter a VALID phone number (8-10 digits)',
				}
				
				
				
			},
								
			
			
			// Do not change code below
			errorPlacement: function(error, element)
			{
				error.insertAfter(element.parent());
			}
		});
	});			

	  
	
	  
})(jQuery);


    
</script>            
       <script>
  (function($) {
  "use strict";

   $(function()
   {
        
         jQuery.validator.addMethod
      ("captchaValidate2",
      function() {
 
 

   var captcha = document.getElementById("image2");
    const usr_input = document
        .getElementById("submit2").value;
     
    // Check whether the input is equal
    // to generated captcha or not
    if (usr_input == captcha.innerHTML) {
        
         var s = document.getElementById("key2")
            .innerHTML = "";
      return true;
    }
    else {
        var s = document.getElementById("key2")
            .innerHTML = "Please enter a valid captcha";
      
        
        return false;
    }


      }
      )
     // Validation
     $("#newsletter-form").validate(
     {   
       
       // Rules for form validation
       rules:
       {
         
         email:
         {
           required: true,
           email: true,
         },
         captcha:
         {
          
           captchaValidate2: true
           
         }
         
       },
                 
       // Messages for form validation
       messages:
       {
         
         email:
         {
           required: 'Please enter your email address',
           email: 'Please enter a VALID email address'
         },
         captcha:
         {
          
           captchaValidate2:''
           
         }
         
         
       },
                 
       
       
       // Do not change code below
       errorPlacement: function(error, element)
       {
         error.insertAfter(element.parent());
       }
     });
   });     

     
   
     
  })(jQuery);


     
  </script>        

<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> 



<script>
  jQuery(".item-boxed").on("click", function(){
    var hotel_id = jQuery(this).attr("data-id");
    var hotel_title = jQuery(this).attr("data-title");

    jQuery(".galleryTitle").html(hotel_title+" gallery");
    jQuery(".gethotel_gallery iframe").attr("src", 'hotel_gallery.php?id='+hotel_id);
});
</script>
 
 <!--<script>
  $(window).load(function(){
                $('#popupForm').modal('show');
            });

</script>-->

<script type="text/javascript">
	$(document).ready(function(){
		$("#popupForm").modal('show');
	});
</script>

<script>
  $(document).ready(function ($) {
    $.fn.menumaker = function (options) {
        var flexmenu = $(this), settings = $.extend({
                format: 'dropdown',
                sticky: false
            }, options);
        return this.each(function () {
            $(this).find('.mobile-menu').on('click', function () {
                $(this).toggleClass('menu-opened');
                var mainmenu = $(this).next('ul');
                if (mainmenu.hasClass('open')) {
                    mainmenu.slideToggle().removeClass('open');
                } else {
                    mainmenu.slideToggle().addClass('open');
                    if (settings.format === 'dropdown') {
                        mainmenu.find('ul').show();
                    }
                }
            });
            flexmenu.find('li ul').parent().addClass('has-sub');
            subToggle = function () {
                flexmenu.find('.has-sub').prepend('<span class="submenu-button"></span>');
                flexmenu.find('.submenu-button').on('click', function () {
                    $(this).toggleClass('submenu-opened');
                    if ($(this).siblings('ul').hasClass('open')) {
                        $(this).siblings('ul').removeClass('open').slideToggle();
                    } else {
                        $(this).siblings('ul').addClass('open').slideToggle();
                    }
                });
            };
            if (settings.format === 'multitoggle')
                subToggle();
            else
                flexmenu.addClass('dropdown');
            if (settings.sticky === true)
                flexmenu.css('position', 'fixed');
            resizeFix = function () {
                var mediasize = 768;
                if ($(window).width() > mediasize) {
                    flexmenu.find('ul').show();
                }
                if ($(window).width() <= mediasize) {
                    flexmenu.find('ul').hide().removeClass('open');
                }
            };
            resizeFix();
            return $(window).on('resize', resizeFix);
        });
    };

   $('#flexmenu').menumaker({ format: 'multitoggle' });
  
}(jQuery));


</script>
<script>
       $('.MoreButton').click(function(){
       
         var text = $(this).text();
        
       if(text == "Read More")
       {
            $(this).addClass("clicked");
            $("#cutText").removeClass("PackageMoreDetailsHide");
            $(this).text("Read Less");
       }
       else
       {
            $(this).removeClass("clicked");
            $("#cutText").addClass("PackageMoreDetailsHide");
            $(this).text("Read More");
       }
    });
    
      $('.testimonialMoreButton').click(function(){
       
         var text = $(this).text();
        
       if(text == "Read More")
       {
            $(this).addClass("clicked");
            $("#testimonialCutText").removeClass("testimonialMore");
            $(this).text("Read Less");
       }
       else
       {
            $(this).removeClass("clicked");
            $("#testimonialCutText").addClass("testimonialMore");
            $(this).text("Read More");
       }
    });
</script>
               
<script type="text/javascript" src="https://www.atlasumrah.com/js/custom.js"></script>  
  
    <script src="https://www.atlasumrah.com/js/umrah-packages.js"></script>
</body>
</html>